import React from "react";
import { TouchableOpacity, Text, ActivityIndicator, ViewStyle } from "react-native";
import * as Haptics from "expo-haptics";
import { Colors, Radii, Space, Fonts } from "../tokens";

type Props = {
  title: string;
  onPress: () => void | Promise<void>;
  loading?: boolean;
  variant?: "primary" | "secondary" | "ghost";
  style?: ViewStyle;
};

export default function Button({ title, onPress, loading, variant = "primary", style }: Props) {
  const base = {
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: Radii.lg,
    alignItems: "center" as const,
    justifyContent: "center" as const,
    borderWidth: 1,
  };

  const variants = {
    primary: { backgroundColor: Colors.primary, borderColor: Colors.primary },
    secondary: { backgroundColor: Colors.surface, borderColor: Colors.border },
    ghost: { backgroundColor: "transparent", borderColor: "transparent" },
  } as const;

  const textColors = {
    primary: "#FFFFFF",
    secondary: Colors.text,
    ghost: Colors.primary,
  } as const;

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={async () => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        await onPress();
      }}
      disabled={!!loading}
      style={[base, variants[variant], style, { opacity: loading ? 0.7 : 1 }]}
    >
      {loading ? (
        <ActivityIndicator color={variant === "primary" ? "#fff" : Colors.primary} />
      ) : (
        <Text style={{ color: textColors[variant], fontSize: Fonts.body, fontWeight: "700" }}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}