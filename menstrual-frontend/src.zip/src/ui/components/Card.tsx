import React from "react";
import { View, ViewStyle } from "react-native";
import { Colors, Radii, Space } from "../tokens";

export default function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return (
    <View
      style={[
        {
          backgroundColor: Colors.surface,
          borderRadius: Radii.md,
          padding: Space.md,
          shadowColor: "#000",
          shadowOpacity: 0.08,
          shadowRadius: 8,
          elevation: 2,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}