import React from "react";
import { TextInput, TextInputProps } from "react-native";
import { Colors, Radii, Space, Fonts } from "../tokens";

export default function Input(props: TextInputProps) {
  return (
    <TextInput
      placeholderTextColor="#9CA3AF"
      {...props}
      style={[
        {
          borderWidth: 1,
          borderColor: Colors.border,
          borderRadius: Radii.sm,
          paddingHorizontal: Space.md,
          paddingVertical: 10,
          fontSize: Fonts.body,
          backgroundColor: Colors.surface,
        },
        props.style,
      ]}
    />
  );
}